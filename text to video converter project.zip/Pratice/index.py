from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re
import os
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup
from moviepy.editor import ImageSequenceClip, concatenate_videoclips
from gtts import gTTS
from moviepy.editor import AudioFileClip
from googletrans import Translator
from sumy.parsers.html import HtmlParser
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer

app = Flask(__name__)

# ... (rest of your code remains the same)




app.secret_key = 'xyzsdfg'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'user-system'

mysql = MySQL(app)

@app.route('/')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM user WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()
        cursor.close()

        if user:
            session['loggedin'] = True
            session['id'] = user['userid']  # Change 'userid' to the correct column name
            session['username'] = user['name']  # Change 'name' to the correct column name
            return redirect(url_for('user'))

        error_message = 'Invalid email or password. Please try again.'
        return render_template('login.html', error=error_message)

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/user', methods=['GET', 'POST'])
def user():
    if 'loggedin' in session:
        if request.method == 'POST':
            # Handle user actions if needed
            pass

        return render_template('user.html', name=session['username'])
    else:
        return redirect(url_for('login'))
    
# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        username = request.form['name']
        password = request.form['password']
        email = request.form['email']
        
        # Connect to MySQL
        cursor = mysql.connection.cursor()

        # Check if the email is already registered
        cursor.execute('SELECT * FROM user WHERE email = %s', (email,))
        existing_user = cursor.fetchone()

        if existing_user:
            error_message = 'Email already exists. Please use a different email.'
            return render_template('register.html', error=error_message)

        # Insert user data into the user table
        cursor.execute('INSERT INTO user (name, email, password) VALUES (%s, %s, %s)', (username, email, password))

        # Commit changes to the database
        mysql.connection.commit()

        # Close the database connection
        cursor.close()

        # Redirect to login after successful registration
        return redirect(url_for('login'))

    return render_template('register.html')  # Display the registration form


def send_get_request(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return response.text
        else:
            return None
    except Exception as e:
        print(f"An error occurred while sending the GET request: {str(e)}")
        return None





def extract_links_and_text(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')

    assets = []
    images = []

    # Extract visible text content
    visible_text = ' '.join(soup.stripped_strings)

    for link in soup.find_all('a'):
        href = link.get('href')
        if href:
            assets.append(href)

    # Extract date, time, and department name using regex
    date_time_match = re.search(r'(\d{1,2} [A-Z]+ \d{4} \d{1,2}:\d{2}[APM]+) by ([A-Z\s]+)', visible_text)

    date = ''
    time = ''
    department = ''

    if date_time_match:
        date_time = date_time_match.group(1)
        department = date_time_match.group(2)

        # Split date and time
        date_parts = re.split(r'\s+', date_time)
        date = ' '.join(date_parts[:3])
        time = date_parts[3]

    return assets, visible_text, date, time, department

def download_images(html_content, base_url):
    image_paths = []

    if not os.path.exists('Scrapped_Images'):
        os.mkdir('Scrapped_Images')

    soup = BeautifulSoup(html_content, 'html.parser')

    ignore_classes = ["fb_b", "twitter_r", "whatsapp_r", "fa-linkedin_r", "log_oo"]
    ignore_image_names = ["facebook.jpg", "email1.png", "linkedin.png", "whatsapp1.png"]

    for img in soup.find_all('img'):
        parent_div = img.find_parent('div', class_=ignore_classes)
        if parent_div:
            continue  # Skip this image if it's inside a div with any of the ignore_classes

        img_url = urljoin(base_url, img.get('src'))
        img_name = os.path.basename(img_url)

        # Check if the image name is in the list of ignore_image_names
        if img_name in ignore_image_names:
            continue  # Skip this image

        # Check if the image name starts with 'ph'
        if img_name.startswith('ph'):
            continue  # Skip this image

        img_path = os.path.join('Scrapped_Images', img_name)

        try:
            img_response = requests.get(img_url)
            if img_response.status_code == 200:
                with open(img_path, 'wb') as img_file:
                    img_file.write(img_response.content)
                image_paths.append(img_path)
        except Exception as e:
            print(f"An error occurred while downloading an image: {str(e)}")

    return image_paths

def filter_links(links):
    filtered_links = []

    for link in links:
        # Exclude links starting with specified patterns
        if not link.startswith(('https://pib.gov.in/', 'https://mail.google.com/')):
            # Exclude redundant and social media sharing links
            if link not in filtered_links and not link.startswith(('https://www.linkedin.com/shareArticle',
                                                                   'http://www.facebook.com/share',
                                                                   'https://api.whatsapp.com/send')):
                filtered_links.append(link)

    return filtered_links

def save_links_to_file(links, filename='webpage_links.txt'):
    with open(filename, 'w', encoding='utf-8') as links_file:
        for link in links:
            links_file.write(link + '\n')

def generate_video(image_folder, output_video, narration_text, language_code='en', video_duration=30):
    # Get all image files in the folder
    image_files = [os.path.join(image_folder, img) for img in os.listdir(image_folder) if img.endswith(('.png', '.jpg', '.jpeg'))]

    # Check if there are any image files
    if not image_files:
        print("No image files found in the specified folder. Cannot generate video.")
        return  # Exit the function if there are no image files

    # Calculate the duration for each image
    image_duration = video_duration / len(image_files)

    # Create video clip from image sequence with the calculated duration
    image_clips = [ImageSequenceClip([img], fps=1, durations=[image_duration]) for img in image_files]

    # Concatenate image clips to create the final video
    final_clip = concatenate_videoclips(image_clips, method="compose")

    # Translate the narration text to the specified language
    if language_code != 'en':
        translator = Translator()
        translated_text = translator.translate(narration_text, dest=language_code).text
    else:
        translated_text = narration_text

    # Save translated text to an audio file
    tts = gTTS(translated_text, lang=language_code)
    tts.save('narration.mp3')

    # Set the audio of the final video to the translated narration
    audio_clip = AudioFileClip('narration.mp3')
    final_clip = final_clip.set_audio(audio_clip)

    # Write the result to a file
    final_clip.write_videofile(output_video, codec="libx264", audio_codec="aac")

    # Clean up temporary audio file
    os.remove('narration.mp3')

def scrape_web_page(url, language_code='en'):
    html_content = send_get_request(url)

    if html_content is not None:
        assets, page_text, date, time, department = extract_links_and_text(html_content)
        filtered_links = filter_links(assets)

        save_links_to_file(filtered_links)

        print("Links on the page:")
        for link in filtered_links:
            print(link)

        # Save extracted text to 'webpage_text.txt'
        with open('webpage_text.txt', 'w', encoding='utf-8') as text_file:
            text_file.write(page_text)

        print("Text from the page has been saved to 'webpage_text.txt'.")

        # Use sumy for text summarization
        parser = PlaintextParser.from_string(page_text, Tokenizer("english"))
        summarizer = LsaSummarizer()
        summarized_text = " ".join([str(sentence) for sentence in summarizer(parser.document, sentences_count=5)])

        # Save summarized text to 'webpage_summary.txt'
        with open('webpage_summary.txt', 'w', encoding='utf-8') as summary_file:
            summary_file.write(summarized_text)

        print("Summarized text has been saved to 'webpage_summary.txt'.")

        print(f"Date: {date}")
        print(f"Time: {time}")
        print(f"Department: {department}")
        print("Links have been saved to 'webpage_links.txt'.")
        print('extracted_text')

        images = download_images(html_content, url)
        print(f"{len(images)} images have been downloaded and saved in the 'Scrapped_Images' folder.")

        # Add the path to the generated video file
        video_output_path = os.path.join('static', 'output_video.mp4')

        # Generate video from images with translated narration
        generate_video('Scrapped_Images', video_output_path, summarized_text, language_code)
    else:
        return redirect(url_for('login'))  # Redirect to the 'login' route if not logged in

@app.route('/generate_video', methods=['GET', 'POST'])
def generate_video_page():
    if 'loggedin' in session:
        if request.method == 'POST' and 'url' in request.form and 'language_code' in request.form:
            url_to_scrape = request.form['url']
            language_code = request.form['language_code']
            scrape_web_page(url_to_scrape, language_code)
            return render_template('user.html', message='Video generation initiated. Check the console for progress.')
        else:
            return render_template('generate_video.html')  # Display the form to input URL and language code
    else:
        return redirect(url_for('login'))


if __name__ == "__main__":
    app.run(debug=True)
